export const Global = {
  url: 'https://apis.logosperu.com.pe/apilandingtienda/public/api',
  urlImages: 'https://apis.logosperu.com.pe/apilandingtienda/public',
  urlproduccion: 'https://api.logosperu.com.pe/public/api',
  urlproduccionImagen: 'https://api.logosperu.com.pe/public'
}

// export const Global = {
//   url: 'https://tajoy.corporacionminz.com/public/api',
//   urlImages: 'https://tajoy.corporacionminz.com/public'
// }
