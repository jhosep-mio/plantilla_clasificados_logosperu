const id: string = ''
const name: string = ''
const onlyname: string = ''
const lastname: string = ''
const email: string = ''
const idRol: number | null = null
const foto: string = ''
const portada: string = ''

export const UserSchema = {
  id,
  name,
  onlyname,
  lastname,
  email,
  idRol,
  foto,
  portada
}
