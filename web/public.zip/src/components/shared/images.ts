import logo from './../../assets/logo/logo.png'
export { logo }
