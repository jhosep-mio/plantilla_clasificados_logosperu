import React, { useEffect, useState } from 'react'
// import fondo1 from './../../assets/home/fondo1.png'
// import fondo3 from './../../assets/home/fondo3.png'
// import flyer1 from './../../assets/flyers/1.jpg'
// import flyer2 from './../../assets/flyers/2.jpg'
import { Swiper, SwiperSlide } from 'swiper/react'
import { Autoplay, Navigation } from 'swiper'
import 'swiper/css/grid'
import 'swiper/css'
import 'swiper/css/pagination'
import 'swiper/css/navigation'
// import { Link } from 'react-router-dom'
import { Global } from '../../helper/Global'
import axios from 'axios'
import Loading from './Loading'
import {
//   type marcasValues,
//   type categoriasValues,
//   type productosValues,
//   type blogsValues,
  type paginaValues
} from '../shared/interface'
// import CardProducto from './modals/CardProducto'
// import { formatearURL } from '../shared/functions'
import { Helmet, HelmetProvider } from 'react-helmet-async'
import { Header } from './estructura/Header'
import { useParams } from 'react-router-dom'

const Home = (): JSX.Element => {
  const [data, setData] = useState<paginaValues | null>(null)
  const { id } = useParams()
  //   const [categorias, setCategorias] = useState([])
  //   const [productos, setProductos] = useState([])
  const [loadingComponents, setLoadingComponents] = useState(true)
  //   const [categoriaActive, setCategoriaActive] = useState(0)
  //   const [marcas, setMarcas] = useState([])
  //   const [blogs, setblogs] = useState([])
  //   const getData = async (
  //     ruta: string,
  //     setDatos: React.Dispatch<React.SetStateAction<never[]>>
  //   ): Promise<void> => {
  //     try {
  //       const request = await axios.get(`${Global.url}/${ruta}`)
  //       setDatos(request.data)
  //     } catch (error) {
  //       console.log(error)
  //     }
  //   }

  const getAllData = async (
    ruta: string,
    setDatos: React.Dispatch<React.SetStateAction<paginaValues | null>>
  ): Promise<void> => {
    try {
      const request = await axios.get(
        `${Global.urlproduccion}/${ruta}`
      )
      setDatos(JSON.parse(request.data.pagina_web))
    } catch (error) {
      console.log(error)
    }
  }

  useEffect(() => {
    window.scrollTo(0, 0)
    Promise.all([
    //   getData('allCategorias', setCategorias),
    //   getData('allProductos', setProductos),
    //   getData('allMarcas', setMarcas),
    //   getData('allBlogs', setblogs),
      getAllData(`oneWeb/${id ?? ''}`, setData)
    ]).then(() => {
      setLoadingComponents(false)
    })
  }, [])

  const color = data?.configuracion?.color ?? '#000' // Color por defecto si no hay configuración

  return (
    <HelmetProvider >
      {loadingComponents
        ? <Loading />
        : (
        <section
        // eslint-disable-next-line @typescript-eslint/ban-ts-comment
        // @ts-expect-error
        style={{ '--color-dynamic': color }}>
          <Helmet>
            <title>{data?.configuracion.nombre}</title>
            <link rel="shortcut icon" href={`${Global.urlproduccionImagen}/clasificados/${data?.configuracion?.icono ?? ''}`} type="image/png"/>
            {data?.banner?.banner1 &&
                <>
                    <meta property="og:image" content={`${Global.urlproduccionImagen}/clasificados/${data?.banner?.banner1 ?? ''}`} />
                </>
            }
          </Helmet>
          <Header datos={data} id ={id}/>
          <section className="pt-[75px] md:pt-0">
            <div className="bg-[#F2F2F0] h-fit w-full min-h-[650px] flex flex-col md:flex-row justify-end">
              <Swiper
                className="w-full h-full"
                modules={[Autoplay, Navigation]}
                autoplay={{
                  delay: 3000,
                  disableOnInteraction: false
                }}
                loop={true}
              >
                  {data?.banner?.banner1 &&
                    <SwiperSlide >
                        <img
                        src={`${Global.urlproduccionImagen}/clasificados/${data?.banner?.banner1 ?? ''}`}
                        alt=""
                        className="w-full h-full object-cover max-h-[650px] block"
                        />
                    </SwiperSlide>
                  }
                  {data?.banner?.banner2 &&
                    <SwiperSlide >
                        <img
                        src={`${Global.urlproduccionImagen}/clasificados/${data?.banner?.banner2 ?? ''}`}
                        alt=""
                        className="w-full h-full object-cover max-h-[650px] block"
                        />
                    </SwiperSlide>
                  }
              </Swiper>
            </div>
          </section>
          <section className="p-4 md:p-8 border-b border-gray-300">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-0">
                {data?.informacion?.imagentitulo1 &&
                    <div className="flex gap-3 items-start md:items-center justify-start md:justify-center">
                        <img
                            src={`${Global.urlproduccionImagen}/clasificados/${data?.informacion?.imagentitulo1 ?? ''}`}
                            alt=""
                            className="object-contain block h-[48px] w-[48px]"
                        />
                        <div className="flex flex-col">
                        <span className="text-sm md:text-base text-black font-bold uppercase">
                            {data?.informacion.titulo1}
                        </span>
                        <span className="text-xs md:text-base">
                            {data?.informacion.subtitulo1}
                        </span>
                        </div>
                    </div> }
               {data?.informacion?.imagentitulo2 &&
              <div className="flex gap-3 items-start md:items-center justify-start md:justify-center">
                <img
                    src={`${Global.urlproduccionImagen}/clasificados/${data?.informacion?.imagentitulo2 ?? ''}`}
                    alt=""
                    className="object-contain block h-[48px] w-[48px]"
                />
                <div className="flex flex-col">
                  <span className="text-sm md:text-base text-black font-bold uppercase">
                    {data?.informacion.titulo2}
                  </span>
                  <span className="text-xs md:text-base">
                    {data?.informacion.subtitulo2}
                  </span>
                </div>
              </div>}
              {data?.informacion?.imagentitulo3 &&
              <div className="flex gap-3 items-start md:items-center justify-start md:justify-center">
                <img
                    src={`${Global.urlproduccionImagen}/clasificados/${data?.informacion?.imagentitulo3 ?? ''}`}
                    alt=""
                    className="object-contain block h-[48px] w-[48px]"
                />
                <div className="flex flex-col">
                  <span className="text-sm md:text-base text-black font-bold uppercase">
                    {data?.informacion.titulo3}
                  </span>
                  <span className="text-xs md:text-base">
                    {data?.informacion.subtitulo3}
                  </span>
                </div>
              </div>}
              {data?.informacion?.imagentitulo4 &&
              <div className="flex gap-3 items-start md:items-center justify-start md:justify-center">
                <img
                    src={`${Global.urlproduccionImagen}/clasificados/${data?.informacion?.imagentitulo4 ?? ''}`}
                    alt=""
                    className="object-contain block h-[48px] w-[48px]"
                />
                <div className="flex flex-col">
                  <span className="text-sm md:text-base text-black font-bold uppercase">
                    {data?.informacion.titulo4}
                  </span>
                  <span className="text-xs md:text-base">
                    {data?.informacion.subtitulo4}
                  </span>
                </div>
              </div>}
            </div>
          </section>
          {/* PRODUCTOS */}
          <section className="md:py-10 w-full px-4 md:px-8" id="productos">
            <div className="flex flex-col justify-center items-center gap-2 md:gap-3">
              <h2 className="font-bold text-3xl md:text-4xl w-full text-center">
                Nuestros productos
              </h2>
              <span className="bg-paleta-500 w-20 h-1 mt-2 rounded-2xl"></span>
              <div className="w-full px-0 md:px-12 relative ">
                <div className="swiper-button-prev"></div>
                <div className="swiper-button-next"></div>
                {/* <Swiper
                  breakpoints={{
                    0: {
                      slidesPerView: 2
                    },
                    1024: {
                      slidesPerView: 5,
                      spaceBetween: 0
                    }
                  }}
                  navigation={{
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                  }}
                  modules={[Navigation, Autoplay]}
                  autoplay={{
                    delay: 3000,
                    reverseDirection: false
                  }}
                  loop
                  className="h-full w-full "
                >
                  {productos
                    ?.filter(
                      (producto: productosValues) =>
                        categoriaActive == 0 ||
                        producto.id_categoria == categoriaActive
                    )
                    .map((producto: productosValues) => (
                      <SwiperSlide
                        key={producto.id}
                        className="w-full border border-gray-300 px-4 py-6"
                      >
                        <CardProducto producto={producto} />
                      </SwiperSlide>
                    ))}
                </Swiper>
                <Swiper
                  breakpoints={{
                    0: {
                      slidesPerView: 2
                    },
                    1024: {
                      slidesPerView: 5,
                      spaceBetween: 0
                    }
                  }}
                  navigation={{
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                  }}
                  modules={[Navigation, Autoplay]}
                  autoplay={{
                    delay: 3000,
                    reverseDirection: true
                  }}
                  loop
                  className="h-full w-full  md:pt-0"
                >
                  {productos
                    ?.filter(
                      (producto: productosValues) =>
                        categoriaActive == 0 ||
                        producto.id_categoria == categoriaActive
                    )
                    .map((producto: productosValues) => (
                      <SwiperSlide
                        key={producto.id}
                        className="w-full border border-gray-300 px-4 py-6"
                      >
                        <CardProducto producto={producto} />
                      </SwiperSlide>
                    ))}
                </Swiper> */}
              </div>
            </div>
          </section>

          {/* CATEGORIAS */}
          {/* <section
            className="py-12 w-full mt-0 md:mt-10 px-4 md:px-8"
            id="categorias"
          >
            <div className="flex flex-col justify-center items-center gap-2 md:gap-3">
              <h2 className="font-bold text-3xl md:text-4xl w-full text-center">
                Nuestras Categorias
              </h2>
              <span className="text-gray-700">Productos increibles</span>
              <span className="bg-paleta-500 w-20 h-1 mt-2 rounded-2xl"></span>
              <div className="w-full">
                <Swiper
                  breakpoints={{
                    0: {
                      slidesPerView: 2
                    },
                    1024: {
                      slidesPerView: 6,
                      spaceBetween: 40
                    }
                  }}
                  pagination={true}
                  modules={[Pagination, Autoplay]}
                  autoplay={{
                    delay: 3000
                  }}
                  loop
                  className="h-full w-full pt-6 pb-12"
                >
                  {categorias.map((categoria: categoriasValues) => (
                    <SwiperSlide key={categoria.id} className="w-full h-full">
                      <a
                        href="#productos"
                        onClick={() => {
                          setCategoriaActive(categoria.id)
                        }}
                        className="w-full flex flex-col gap-6 "
                      >
                        <img
                          src={`${Global.urlImages}/categorias/${categoria.imagen1}`}
                          alt=""
                          className="w-full h-[230px] p-4 object-cover border border-gray-300 rounded-md"
                        />
                        <span className="w-full text-center font-bold">
                          {categoria.nombre}
                        </span>
                      </a>
                    </SwiperSlide>
                  ))}
                </Swiper>
              </div>
            </div>
          </section> */}
          {/* FLYERS */}
          {/* <section className="px-4 md:px-8 w-full pb-10">
            <div className="w-full flex flex-col md:flex-row justify-between md:h-[400px] gap-4">
              <img
                src={flyer1}
                alt=""
                className="w-full md:w-1/2 object-cover h-[150px] md:h-auto"
              />
              <img
                src={flyer2}
                alt=""
                className="w-full md:w-1/2 object-cover h-[150px] md:h-auto"
              />
            </div>
          </section> */}
          {/* SUGERENCIAS */}
          {/* <section className="py-12 w-full px-4 md:px-8 max-w-[1450px] mx-auto">
            <div className="flex flex-col justify-center items-center gap-2 md:gap-3">
              <h2 className="font-bold text-3xl md:text-4xl w-full text-center">
                Sugerencias para ti
              </h2>
              <span className="text-gray-700">Productos increibles</span>
              <span className="bg-paleta-500 w-20 h-1 mt-2 rounded-2xl"></span>
              <div className="w-full">
                <Swiper
                  breakpoints={{
                    0: {
                      slidesPerView: 1
                    },
                    1024: {
                      slidesPerView: 2,
                      spaceBetween: 40
                    }
                  }}
                  pagination={true}
                  modules={[Pagination, Autoplay]}
                  autoplay={{
                    delay: 3000
                  }}
                  loop
                  className="h-full w-full pt-6 pb-12"
                >
                  {productos
                    ?.sort(() => Math.random() - 0.5)
                    .slice(0, 10)
                    .map((producto: productosValues) => (
                      <SwiperSlide
                        key={producto.id}
                        className="w-full h-[350px] md:h-[300px]"
                      >
                        <div className="w-full h-full flex items-center gap-6 border-4 border-paleta-500 px-4 py-6">
                          <div className="w-1/2 h-full">
                            <img
                              src={`${Global.urlImages}/productos/${producto.imagen1}`}
                              alt=""
                              className="w-full h-full my-auto object-contain"
                            />
                          </div>
                          <div className="h-full w-1/2">
                            <div className="w-full h-full flex flex-col gap-0 justify-between">
                              <span className="text-gray-700 text-sm underline">
                                {producto.categoria}
                              </span>
                              <h3 className="font-bold text-lg line-clamp-1">
                                {producto.nombre}
                              </h3>
                              <div className="pt-6 justify-between ">
                                <div
                                  className="text-gray-700 line-clamp-4"
                                  dangerouslySetInnerHTML={{
                                    __html: producto?.caracteristicas ?? ''
                                  }}
                                ></div>
                              </div>
                              <Link
                                to={`/producto/${producto.id}-${formatearURL(
                                  producto.nombre
                                )}-${producto.codigo}`}
                                className="rounded-2xl bg-paleta-500 hover:bg-paleta-500/80 transition-colors px-6 text-white mt-4 text-sm py-2 w-fit"
                              >
                                Ver producto
                              </Link>
                            </div>
                          </div>
                        </div>
                      </SwiperSlide>
                    ))}
                </Swiper>
              </div>
            </div>
          </section> */}

          {/* SEGUNDO FONDO */}
          {/* <section>
            <div className="bg-[#F2F2F0] h-[450px] md:h-[550px] w-full flex justify-end relative px-4 md:px-0 mt-10 md:mt-0">
              <div className="w-1/2 h-full absolute inset-0">
                <img
                  src={fondo1}
                  alt=""
                  className="w-full h-full object-cover hidden md:block"
                />
              </div>
              <div className="w-full md:w-1/2 mx-auto h-full flex justify-center items-center flex-col gap-4 z-10">
                <span className="font-bold text-3xl md:text-5xl text-center">
                  BIENVENIDOS A FAUGET
                </span>
                <span className="font-medium text-sm text-gray-700 text-center">
                  Brindamos toda la información y soporte con relación a
                  nuestros productos y/o servicios. Gestionamos tus Quejas,
                  devoluciones y sugerencias con los debidos procesos, para
                  poder brindarte una respuesta oportuna.
                </span>
                <a
                  href="#contacto"
                  className="bg-paleta-500 text-sm md:text-base hover:bg-paleta-500/80 transition-colors px-4 md:px-6 py-2 md:py-3 rounded-lg text-white"
                >
                  Contactanos
                </a>
              </div>
              <div className="w-1/2 h-full hidden md:block absolute right-0 top-0 bottom-0">
                <img
                  src={fondo3}
                  alt=""
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </section> */}
          {/* MARCAS */}
          {/* <section className="w-full relative">
            <div className="w-[85%] mx-auto absolute right-0 left-0 -top-20 bg-white p-4 border border-gray-300 rounded-lg">
              <Swiper
                breakpoints={{
                  0: {
                    slidesPerView: 2
                  },
                  1024: {
                    slidesPerView: 5,
                    spaceBetween: 40
                  }
                }}
                pagination={true}
                modules={[Pagination, Autoplay]}
                autoplay={{
                  delay: 3000
                }}
                loop
                className="h-full w-full md:pt-6 pb-4 md:pb-12"
              >
                {marcas.map((marca: marcasValues) => (
                  <SwiperSlide key={marca.id} className="w-full h-full">
                    <div className="w-full">
                      <img
                        src={`${Global.urlImages}/marcas/${marca.imagen1}`}
                        alt=""
                        className="w-full h-[100px] object-contain mx-auto filter grayscale"
                      />
                    </div>
                  </SwiperSlide>
                ))}
              </Swiper>
            </div>
          </section> */}
          {/* BLOGS */}
          {/* <section className="pt-28 md:pt-48 px-4 md:px-8" id="blogs">
            <div className="flex flex-col justify-center items-center gap-2 md:gap-3">
              <h2 className="font-bold text-3xl md:text-4xl w-full text-center">
                Ultimas noticias
              </h2>
              <span className="text-gray-700">Información de interes</span>
              <span className="bg-paleta-500 w-20 h-1 mt-2 rounded-2xl"></span>
            </div>
            <Swiper
              breakpoints={{
                0: {
                  slidesPerView: 1,
                  spaceBetween: 20
                },
                1024: {
                  slidesPerView: 4,
                  spaceBetween: 40
                }
              }}
              pagination={true}
              modules={[Pagination, Autoplay]}
              autoplay={{
                delay: 3000
              }}
              loop
              className="h-full w-full pt-6 pb-12"
            >
              {blogs.map((blog: blogsValues) => (
                <SwiperSlide key={blog.id} className="w-full h-full">
                  <div className="flex w-full flex-col">
                    <img
                      src={`${Global.urlImages}/blogs/${blog.imagen1}`}
                      alt=""
                      className="w-full h-[250px] object-cover"
                    />
                    <h3 className="font-bold mt-6 text-base">{blog.titulo}</h3>
                    <div
                      className="line-clamp-2 text-justify mt-5 text-gray-700"
                      dangerouslySetInnerHTML={{
                        __html: blog?.caracteristicas ?? ''
                      }}
                    ></div>
                    <Link
                      to={`/blog/${blog.id}-${formatearURL(blog.titulo)}`}
                      className="text-paleta-500 mt-4 hover:text-paleta-500/80 transition-colors underline"
                    >
                      Ver más
                    </Link>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </section> */}
        </section>
          )}
    </HelmetProvider>
  )
}

export default Home
