declare module 'swiper'
